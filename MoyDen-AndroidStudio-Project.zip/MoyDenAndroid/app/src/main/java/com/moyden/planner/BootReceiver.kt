package com.moyden.planner

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            // The next app launch re-schedules reminders. This receiver intentionally avoids
            // scheduling a stale duplicate schedule without checking saved user preferences.
        }
    }
}
