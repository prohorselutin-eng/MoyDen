package com.moyden.planner

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("moyden", MODE_PRIVATE) }
    private val tasks = listOf(
        Task("wake","08:00","Подъём и завтрак","Умыться, поесть и спокойно подготовиться.","30 минут","☀"),
        Task("study1","08:30","Учёба · блок 1","Начни с самой сложной темы.","1 ч 30 мин","📚"),
        Task("break1","10:00","Перерыв","Вода, разминка, немного пройтись.","15 минут","☕"),
        Task("study2","10:15","Учёба · блок 2","Закрепи материал и проверь себя вопросами.","1 ч 30 мин","📚"),
        Task("lunch","11:45","Обед и отдых","Поешь и отдохни без спешки.","1 час","🍽"),
        Task("read1","12:45","Чтение · блок 1","Убери телефон и читай в комфортном темпе.","1 час","📖"),
        Task("walk","13:45","Спорт или прогулка","Выйди на улицу или сделай тренировку.","1 час","🏃"),
        Task("break2","14:45","Перезагрузка","Перекус, вода и небольшой отдых.","15 минут","☕"),
        Task("study3","15:00","Учёба · блок 3","Повторение и закрепление. Итого учёбы — 4 часа.","1 час","📚"),
        Task("read2","16:15","Чтение · блок 2","Ещё один час — цель чтения выполнена.","1 час","📖"),
        Task("dinner","17:15","Ужин и свободное время","Еда, душ и отдых.","1 ч 15 мин","🍽"),
        Task("games","18:30","Игры — заслуженная награда","Играй спокойно: основные цели дня сделаны.","2 часа","🎮"),
        Task("evening","20:30","Свободный вечер","Общение, отдых и подготовка ко сну.","Вечер","🌙")
    )
    private val green = Color.rgb(183,243,151)
    private val bg = Color.rgb(16,19,26)
    private val panel = Color.rgb(25,30,41)
    private val muted = Color.rgb(170,179,196)
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 12)
        }
        ensureDate()
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18),dp(24),dp(18),dp(30)) }
        scroll.addView(content)
        setContentView(scroll)
        render()
        scheduleReminders()
    }

    private fun ensureDate() {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        if (prefs.getString("date","") != today) {
            prefs.edit().clear().putString("date", today).putBoolean("reminders", true).apply()
        }
    }

    private fun render() {
        content.removeAllViews()
        val date = SimpleDateFormat("EEEE, d MMMM", Locale("ru")).format(Date())
        addText("ТВОЙ ЛИЧНЫЙ ПЛАНЕР", 12f, green, true, 0, 3)
        addText("Мой день ✨", 30f, Color.WHITE, true, 0, 3)
        addText(date.replaceFirstChar { it.uppercase() }, 14f, muted, false, 0, 16)
        val goalIds = listOf("study1","study2","study3","read1","read2","walk","games")
        val checked = goalIds.count { prefs.getBoolean("done_$it", false) }
        val hero = card()
        hero.addView(textView(if (checked == goalIds.size) "Ты сделал это. Гордись собой! 🏆" else if (checked > 0) "Уже есть прогресс. Продолжай!" else "Не нужно быть идеальным. Просто начни.", 19f, Color.WHITE, true))
        hero.addView(textView("Сначала дела — потом игры без чувства вины. Если отстал от графика, просто продолжай со следующего пункта.", 14f, muted, false).apply { setPadding(0,dp(8),0,dp(12)) })
        hero.addView(textView("Прогресс основных занятий: $checked из ${goalIds.size}", 13f, green, true))
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progress = checked * 100 / goalIds.size }
        hero.addView(bar)
        addText("План на сегодня", 20f, Color.WHITE, true, 0, 8)
        tasks.forEach { task ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12),dp(12),dp(12),dp(12)); setBackgroundColor(panel)
            }
            val time = textView(task.time, 13f, green, true)
            row.addView(time, LinearLayout.LayoutParams(dp(52), -2))
            val center = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            center.addView(textView("${task.emoji}  ${task.title}", 15f, Color.WHITE, true))
            center.addView(textView(task.description, 12f, muted, false).apply { setPadding(0,dp(4),0,dp(4)) })
            center.addView(textView(task.duration, 12f, green, false))
            row.addView(center, LinearLayout.LayoutParams(0, -2, 1f))
            val cb = CheckBox(this).apply {
                buttonTintList = android.content.res.ColorStateList.valueOf(green)
                isChecked = prefs.getBoolean("done_${task.id}", false)
                setOnCheckedChangeListener { _, value ->
                    prefs.edit().putBoolean("done_${task.id}", value).apply()
                    render()
                }
            }
            row.addView(cb)
            val lp = LinearLayout.LayoutParams(-1,-2).apply { bottomMargin = dp(8) }
            content.addView(row, lp)
        }
        addText("Напоминания", 19f, Color.WHITE, true, 0, 6)
        val reminderRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12),dp(10),dp(12),dp(10)); setBackgroundColor(panel) }
        reminderRow.addView(textView("Напоминать о начале каждого блока",14f,Color.WHITE,false), LinearLayout.LayoutParams(0,-2,1f))
        val toggle = Switch(this).apply {
            isChecked = prefs.getBoolean("reminders",true)
            setOnCheckedChangeListener { _, enabled -> prefs.edit().putBoolean("reminders",enabled).apply(); if(enabled) scheduleReminders() else cancelReminders(); Toast.makeText(this@MainActivity, if(enabled) "Напоминания включены" else "Напоминания выключены", Toast.LENGTH_SHORT).show()
            }
        }
        reminderRow.addView(toggle); content.addView(reminderRow)
        val test = Button(this).apply { text = "Проверить уведомление"; setOnClickListener { ReminderReceiver.show(this@MainActivity, "Мой день", "Ты справишься! Сделай следующий маленький шаг 💪") } }
        content.addView(test)
        addText("Отметки сохраняются на телефоне. Если не успел по расписанию — не бросай весь день, просто продолжай.", 12f, muted, false, 0, 10)
    }

    private fun scheduleReminders() {
        if (!prefs.getBoolean("reminders",true)) return
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        tasks.filter { it.id !in listOf("break1","break2","evening") }.forEachIndexed { index, task ->
            val parts = task.time.split(":")
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, parts[0].toInt()); set(Calendar.MINUTE, parts[1].toInt()); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND,0)
                if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR,1)
            }
            val intent = Intent(this, ReminderReceiver::class.java).putExtra("title", task.title).putExtra("body", task.description).putExtra("id", index)
            val pi = PendingIntent.getBroadcast(this, index+100, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            try {
                if (Build.VERSION.SDK_INT >= 31 && am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
            } catch (_: Exception) { am.set(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi) }
        }
    }

    private fun cancelReminders() {
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        tasks.indices.forEach { i ->
            val pi = PendingIntent.getBroadcast(this, i+100, Intent(this, ReminderReceiver::class.java), PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
            if (pi != null) am.cancel(pi)
        }
    }
    private fun card(): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(15),dp(15),dp(15),dp(15)); setBackgroundColor(panel) }
        content.addView(box, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin = dp(20) })
        return box
    }
    private fun addText(s:String, size:Float, color:Int, bold:Boolean, top:Int, bottom:Int) {
        content.addView(textView(s,size,color,bold).apply { setPadding(0,dp(top),0,dp(bottom)) })
    }
    private fun textView(s:String, size:Float, color:Int, bold:Boolean): TextView = TextView(this).apply {
        text=s; textSize=size; setTextColor(color); if(bold) setTypeface(typeface,Typeface.BOLD); setLineSpacing(dp(2).toFloat(),1f)
    }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    data class Task(val id:String,val time:String,val title:String,val description:String,val duration:String,val emoji:String)
}
