package com.moyden.planner

import android.app.*
import android.content.*
import android.os.Build

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        show(context, intent.getStringExtra("title") ?: "Мой день", intent.getStringExtra("body") ?: "Пора сделать маленький шаг.")
    }
    companion object {
        private const val CHANNEL = "moyden_reminders"
        fun show(context: Context, title: String, body: String) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel(CHANNEL, "Напоминания планера", NotificationManager.IMPORTANCE_DEFAULT))
            val open = PendingIntent.getActivity(context, 1, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(context, CHANNEL) else Notification.Builder(context)
            val notification = builder.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(body).setAutoCancel(true).setContentIntent(open).build()
            manager.notify((System.currentTimeMillis() % 100000).toInt(), notification)
        }
    }
}
